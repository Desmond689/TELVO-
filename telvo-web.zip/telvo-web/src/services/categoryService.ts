// src/services/categoryService.ts
import { collection, getDocs, orderBy, query, where } from 'firebase/firestore';
import { db, COLLECTIONS } from '@/lib/firebase';
import type { ServiceCategory } from '@/types';

// Fallback categories shown if /categories hasn't been seeded yet in
// Firestore, so the site never renders empty. Real data always wins.
export const DEFAULT_CATEGORIES: ServiceCategory[] = [
  { id: 'plumbing', slug: 'plumbing', name: { en: 'Plumbing', fr: 'Plomberie' }, icon: 'Wrench', isActive: true, sortOrder: 1 },
  { id: 'electrical', slug: 'electrical', name: { en: 'Electrical', fr: 'Électricité' }, icon: 'Zap', isActive: true, sortOrder: 2 },
  { id: 'mechanics', slug: 'mechanics', name: { en: 'Mechanics', fr: 'Mécanique' }, icon: 'Car', isActive: true, sortOrder: 3 },
  { id: 'cleaning', slug: 'cleaning', name: { en: 'Cleaning', fr: 'Nettoyage' }, icon: 'Sparkles', isActive: true, sortOrder: 4 },
  { id: 'painting', slug: 'painting', name: { en: 'Painting', fr: 'Peinture' }, icon: 'Paintbrush', isActive: true, sortOrder: 5 },
  { id: 'construction', slug: 'construction', name: { en: 'Construction', fr: 'Construction' }, icon: 'HardHat', isActive: true, sortOrder: 6 },
  { id: 'carpentry', slug: 'carpentry', name: { en: 'Carpentry', fr: 'Menuiserie' }, icon: 'Hammer', isActive: true, sortOrder: 7 },
  { id: 'electronics', slug: 'electronics', name: { en: 'Electronics Repair', fr: 'Réparation électronique' }, icon: 'Smartphone', isActive: true, sortOrder: 8 },
  { id: 'ac_refrigeration', slug: 'ac-refrigeration', name: { en: 'AC & Refrigeration', fr: 'Climatisation & Froid' }, icon: 'Snowflake', isActive: true, sortOrder: 9 },
  { id: 'moving', slug: 'moving', name: { en: 'Moving', fr: 'Déménagement' }, icon: 'Truck', isActive: true, sortOrder: 10 },
  { id: 'beauty', slug: 'beauty', name: { en: 'Beauty', fr: 'Beauté' }, icon: 'Sparkle', isActive: true, sortOrder: 11 },
  { id: 'tech', slug: 'tech-services', name: { en: 'Tech Services', fr: 'Services Tech' }, icon: 'Laptop', isActive: true, sortOrder: 12 },
  { id: 'other', slug: 'other', name: { en: 'Other', fr: 'Autre' }, icon: 'MoreHorizontal', isActive: true, sortOrder: 13 },
];

export async function getCategories(): Promise<ServiceCategory[]> {
  try {
    const q = query(collection(db, COLLECTIONS.CATEGORIES), where('isActive', '==', true), orderBy('sortOrder', 'asc'));
    const snap = await getDocs(q);
    if (snap.empty) return DEFAULT_CATEGORIES;
    return snap.docs.map((d) => ({ id: d.id, ...d.data() } as ServiceCategory));
  } catch {
    return DEFAULT_CATEGORIES;
  }
}
