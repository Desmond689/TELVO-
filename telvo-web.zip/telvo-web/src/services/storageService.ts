// src/services/storageService.ts
import { ref, uploadBytes, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { storage } from '@/lib/firebase';

const MAX_FILE_BYTES = 8 * 1024 * 1024; // 8MB
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

export async function uploadImage(file: File, path: string): Promise<string> {
  if (!ALLOWED_TYPES.includes(file.type)) {
    throw new Error('Only JPG, PNG, or WEBP images are allowed.');
  }
  if (file.size > MAX_FILE_BYTES) {
    throw new Error('Images must be smaller than 8MB.');
  }
  const storageRef = ref(storage, path);
  await uploadBytes(storageRef, file);
  return getDownloadURL(storageRef);
}

const MAX_APK_BYTES = 150 * 1024 * 1024; // 150MB

// Admin-only (enforced by storage.rules): uploads a new APK build to
// app_releases/{versionCode}.apk and returns its public download URL,
// which the caller then saves onto app_config/latest_app in Firestore.
export async function uploadApk(file: File, versionCode: number, onProgress?: (pct: number) => void): Promise<{ url: string; sizeBytes: number }> {
  if (!file.name.toLowerCase().endsWith('.apk')) {
    throw new Error('Please choose a .apk file.');
  }
  if (file.size > MAX_APK_BYTES) {
    throw new Error('APK must be smaller than 150MB.');
  }
  const storageRef = ref(storage, `app_releases/${versionCode}.apk`);
  const task = uploadBytesResumable(storageRef, file, { contentType: 'application/vnd.android.package-archive' });
  await new Promise<void>((resolve, reject) => {
    task.on(
      'state_changed',
      (snap) => onProgress?.(Math.round((snap.bytesTransferred / snap.totalBytes) * 100)),
      reject,
      () => resolve()
    );
  });
  const url = await getDownloadURL(storageRef);
  return { url, sizeBytes: file.size };
}
