import type { FormEvent } from 'react';
import { useEffect, useState, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Send } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { EmptyState } from '@/components/ui/EmptyState';
import { useAuth } from '@/contexts/AuthContext';
import { listenToThreads, listenToMessages, sendMessage, ensureChatThread } from '@/services/chatService';
import { getUserById } from '@/services/userService';
import type { ChatThread, ChatMessage, TelvoUser } from '@/types';
import { timeAgo } from '@/utils/format';
import { MessageCircle } from 'lucide-react';

export function Messages() {
  const { profile } = useAuth();
  const [params] = useSearchParams();
  const withUserId = params.get('with');
  const [threads, setThreads] = useState<ChatThread[] | null>(null);
  const [participants, setParticipants] = useState<Record<string, TelvoUser>>({});
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [text, setText] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!profile) return;
    return listenToThreads(profile.id, setThreads);
  }, [profile]);

  useEffect(() => {
    if (!threads && !withUserId) return;
    const otherIds = new Set<string>();
    threads?.forEach((t) => t.participantIds.forEach((p) => p !== profile?.id && otherIds.add(p)));
    if (withUserId) otherIds.add(withUserId);
    otherIds.forEach((id) => {
      if (!participants[id]) getUserById(id).then((u) => u && setParticipants((prev) => ({ ...prev, [id]: u })));
    });
  }, [threads, withUserId, participants]);

  useEffect(() => {
    if (!profile) return;
    if (withUserId) {
      ensureChatThread(profile.id, withUserId).then(setActiveChatId);
      return;
    }
    if (threads === null) return;
    if (threads.length > 0) {
      setActiveChatId((prev) => prev || threads[0].id);
    } else {
      setActiveChatId(null);
    }
  }, [withUserId, threads, profile]);

  const threadList = threads ?? [];
  const pendingThread = withUserId && activeChatId && !threadList.some((t) => t.id === activeChatId)
    ? { id: activeChatId, participantIds: [profile?.id ?? '', withUserId], jobId: undefined, lastMessage: 'Starting a conversation...', lastMessageAt: null } as ChatThread
    : undefined;
  const displayedThreads = pendingThread ? [pendingThread, ...threadList] : threadList;

  useEffect(() => {
    if (!activeChatId) return;
    return listenToMessages(activeChatId, setMessages);
  }, [activeChatId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const activeThread = activeChatId ? displayedThreads.find((t) => t.id === activeChatId) : undefined;
  const activeOtherId = activeThread ? activeThread.participantIds.find((p) => p !== profile?.id) : withUserId;

  const handleSend = async (e: FormEvent) => {
    e.preventDefault();
    if (!profile || !activeChatId || !text.trim()) return;
    const otherId = threads?.find((t) => t.id === activeChatId)?.participantIds.find((p) => p !== profile.id) || withUserId;
    if (!otherId) return;
    await sendMessage(activeChatId, profile.id, otherId, text.trim());
    setText('');
  };

  if (!profile) return null;

  return (
    <div className="h-[calc(100vh-8rem)] flex gap-4">
      <Card className="w-full sm:w-72 flex-shrink-0 overflow-y-auto hidden sm:block">
        {threads === null && <p className="p-4 text-sm text-ink-400">Loading...</p>}
        {threads?.length === 0 && !withUserId && <div className="p-4"><EmptyState icon={<MessageCircle size={32} />} title="No conversations yet" description="Messages with professionals and customers will appear here." /></div>}
        {displayedThreads.map((t) => {
          const otherId = t.participantIds.find((p) => p !== profile.id);
          const other = otherId ? participants[otherId] : undefined;
          return (
            <button
              key={t.id}
              onClick={() => setActiveChatId(t.id)}
              className={`w-full flex items-center gap-3 p-3 text-left border-b border-ink-100 hover:bg-ink-50 ${activeChatId === t.id ? 'bg-brand-50' : ''}`}
            >
              <span className="w-10 h-10 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center text-sm font-bold flex-shrink-0">
                {other?.fullName?.[0] || '?'}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-ink-900 truncate">{other?.fullName || 'User'}</p>
                <p className="text-xs text-ink-400 truncate">{t.lastMessage || 'No messages yet'}</p>
              </div>
            </button>
          );
        })}
      </Card>

      <Card className="flex-1 flex flex-col overflow-hidden">
        {activeChatId ? (
          <>
            <div className="px-4 py-3 border-b border-ink-100 font-medium text-ink-900">
              {(activeOtherId && participants[activeOtherId]?.fullName) || 'Conversation'}
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((m) => (
                <div key={m.id} className={`flex ${m.senderId === profile.id ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm ${m.senderId === profile.id ? 'bg-brand-500 text-white' : 'bg-ink-100 text-ink-800'}`}>
                    {m.message}
                    <p className={`text-[10px] mt-1 ${m.senderId === profile.id ? 'text-brand-100' : 'text-ink-400'}`}>{timeAgo(m.timestamp)}</p>
                  </div>
                </div>
              ))}
              <div ref={bottomRef} />
            </div>
            <form onSubmit={handleSend} className="p-3 border-t border-ink-100 flex gap-2">
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Type a message..."
                className="flex-1 h-11 px-4 rounded-xl border border-ink-200 text-sm outline-none focus:ring-2 focus:ring-brand-500/30 focus:border-brand-500"
              />
              <button type="submit" className="w-11 h-11 rounded-xl bg-brand-500 text-white flex items-center justify-center hover:bg-brand-600">
                <Send size={17} />
              </button>
            </form>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-sm text-ink-400">Select a conversation</div>
        )}
      </Card>
    </div>
  );
}
