import { useState } from 'react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { useAuth } from '@/contexts/AuthContext';

export function CustomerSettings() {
  const { signOut, profile } = useAuth();
  const [notifPrefs, setNotifPrefs] = useState({ jobs: true, messages: true, marketing: false });

  return (
    <div className="max-w-xl space-y-6">
      <h1 className="text-2xl font-bold text-ink-900">Settings</h1>
      <Card className="p-6">
        <h2 className="font-semibold text-ink-900 mb-4">Notification Preferences</h2>
        <div className="space-y-3">
          {[
            { key: 'jobs', label: 'Job & quote updates' },
            { key: 'messages', label: 'New messages' },
            { key: 'marketing', label: 'Product updates & offers' },
          ].map((p) => (
            <label key={p.key} className="flex items-center justify-between text-sm text-ink-700">
              {p.label}
              <input
                type="checkbox"
                checked={(notifPrefs as any)[p.key]}
                onChange={(e) => setNotifPrefs((prev) => ({ ...prev, [p.key]: e.target.checked }))}
                className="rounded border-ink-300 text-brand-500 focus:ring-brand-500"
              />
            </label>
          ))}
        </div>
      </Card>
      <Card className="p-6">
        <h2 className="font-semibold text-ink-900 mb-2">Language</h2>
        <p className="text-sm text-ink-500 mb-3">Choose your preferred language</p>
        <select className="h-10 px-3 rounded-lg border border-ink-200 text-sm">
          <option value="en">English</option>
          <option value="fr">Français</option>
        </select>
      </Card>
      <Card className="p-6">
        <h2 className="font-semibold text-red-600 mb-2">Account</h2>
        <p className="text-sm text-ink-500 mb-4">Signed in as {profile?.email || profile?.phoneNumber}</p>
        <Button variant="danger" onClick={() => signOut()}>Sign out</Button>
      </Card>
    </div>
  );
}
